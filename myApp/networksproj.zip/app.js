var express = require('express');
var path = require('path');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function(req, res) {
  res.render('home')
});
app.get('/registration', (req, res) => {
  res.render('registration'); 
});
app.get('/hiking', function(req, res) {
  res.render('hiking')
});
app.get('/cities', function(req, res) {
  res.render('cities')
});
app.get('/islands', function(req, res) {
  res.render('islands')
});
app.get('/paris', function(req, res) {
  res.render('paris')
});
app.get('/rome', function(req, res) {
  res.render('rome')
});
app.get('/inca', function(req, res) {
  res.render('inca')
});
app.get('/annapurna', function(req, res) {
  res.render('annapurna')
});
app.get('/bali', function(req, res) {
  res.render('bali')
});
app.get('/santorini', function(req, res) {
  res.render('santorini')
});
app.get('/wanttogo', function(req, res) {
  res.render('wanttogo')
});

app.post('/search', (req, res) => {
  const searchKeyword = req.body.Search.toLowerCase();
  const destinations = [
      { name: "Rome", link: "/cities/rome" },
      { name: "Paris", link: "/destinations/paris" },
  ];

  const results = destinations.filter(destination =>
      destination.name.toLowerCase().includes(searchKeyword)
  );

  if (results.length === 0) {
      res.render('searchResults', { message: "Destination not Found", results: [] });
  } else {
      res.render('searchResults', { message: null, results });
  }
});


app.listen(3000, () => {
  console.log('Server is running on port 3000');
});


